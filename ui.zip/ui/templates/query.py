import sqlite3

create_table_lokation = """CREATE TABLE IF NOT EXISTS lokation (
    id INTEGER PRIMARY KEY,
    adresse TEXT
)"""
create_table_kunde = """CREATE TABLE IF NOT EXISTS kunde ( navn adresse telefonnummer mail
    id INTEGER PRIMARY KEY,
    navn TEXT, 
    adresse TEXT,
    telefon INT,
    mail TEXT
)"""
create_table_clever = """CREATE TABLE IF NOT EXISTS clever (
    id INTEGER PRIMARY KEY,
    område INT, 
    elpris REAL
    FOREIGN KEY (lokation_id) REFERENCES lokation(id),
    FOREIGN KEY (kunde_id) REFERENCES kunde(id),
    FOREIGN KEY (strøm_id) REFERENCES strøm(id),


)"""
create_table_strøm = """CREATE TABLE IF NOT EXISTS strøm (
    id INTEGER PRIMARY KEY,
    elpris REAL
    FOREIGN KEY (lokation_id) REFERENCES lokation(id)

)"""
with sqlite3.connect('cleverr.db') as conn:
    c = conn.cursor()
    c.execute(create_table_lokation)
    c.execute("INSERT INTO lokation(område) VALUES(København)")
    