from flask import Flask, render_template, request, redirect, url_for
from database import connection, execute_query, execute_read_query
import sqlite3
import os
import requests
import matplotlib.pyplot as plt

plt.switch_backend('agg')
app = Flask(__name__) 

def elpriser():
    elprisdata = []
    return elprisdata

#Starten af hjemmesiden (hjem)
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/elpris", methods=['GET'])
def startdata():
    lokation = execute_read_query(connection, "SELECT * FROM lokation")
    elprisdata = elpriser()
    return render_template("elpris.html", lokation=lokation, elprisdata=elprisdata)

@app.route("/opret_lokation", methods=['POST'])
def get_lokation():
    if request.method == 'POST':
        lokation = request.form['lokation']
        insert_lokation = f"""INSERT INTO lokation (lokation) VALUES ('{lokation}')"""
        execute_query(connection, insert_lokation)
    return redirect(url_for('elpris'))

@app.route("/elprisdata", methods=['POST'])
def data():
    endpoint = "https://api.energidataservice.dk/dataset/Elspotprices?start"
    params = {
        "format": "json"
    }
    response = requests.get(endpoint, params=params)
    
    tidspunkt = []
    el = []

    print(response.json())
    for x in response.json()['records']:
        if x['PriceArea'] == 'DK1':
            tidspunkt.append(x['HourDK'])
            el.append(x['SpotPriceDKK'])

    plt.plot(tidspunkt, el)
    plt.ylabel('EL pris')
    plt.xlabel('Tidspunkt')
    plt.xticks(rotation=90)
    plt.ylim(0, max(el)+100) 
    plt.xticks(tidspunkt[::5])
    plt.subplots_adjust(bottom=0.5)
    plt.savefig('static/graf.png')
    
    return redirect(url_for("strømforbrug"))

#Siden Strømforbrug
@app.route("/strømforbrug")
def strømforbrug():
    return render_template("strømforbrug.html")

@app.route("/<string:lokation>", methods=['GET'])
def lokations(lokations):
    lokationer = execute_read_query(connection, "SELECT * FROM lokation")
    for l in lokationer:
        if l[1] == lokations:
            with sqlite3.connect('cleverr.db') as conn:
                c = conn.cursor()
                c.execute("SELECT * FROM lokation WHERE lokation_id=?", (l[0],))
                lokation = c.fetchall()
            return render_template("elpris.html", lokations=l)
    return redirect(url_for('elpris'))

if __name__ == '__main__':
    app.run(debug=True)
